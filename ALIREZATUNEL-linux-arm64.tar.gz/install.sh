#!/usr/bin/env bash
# Installs this package, never downloads an upstream Kariz release over it.
set -euo pipefail
project_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
mode="${1:-panel}"
case "$mode" in panel|agent) ;; *) echo 'Usage: sudo bash install.sh panel|agent [--no-build]' >&2; exit 2;; esac
[[ $EUID -eq 0 ]] || { echo 'Run this installer with sudo.' >&2; exit 1; }
[[ $(uname -s) == Linux ]] || { echo 'Linux with systemd is required for installation.' >&2; exit 1; }
command -v systemctl >/dev/null || { echo 'systemd is required. Use process mode only for development.' >&2; exit 1; }
if [[ ${2:-} != --no-build ]]; then bash "$project_root/scripts/build-alirezatunel.sh"; fi
for binary in kariz kariz-panel alirezatunel-backpack; do
  [[ -x "$project_root/build/$binary" ]] || { echo "Missing build/$binary. Build the project first." >&2; exit 1; }
done
(cd "$project_root/build" && sha256sum -c SHA256SUMS)
install -d -m 0700 /etc/kariz /etc/kariz/backpack /etc/kariz-panel /var/lib/kariz-panel
for binary in kariz kariz-panel alirezatunel-backpack; do
  # Move atomically: an existing executable may still be running.
  install -m 0755 "$project_root/build/$binary" "/usr/local/bin/$binary.new"
  mv -f "/usr/local/bin/$binary.new" "/usr/local/bin/$binary"
done
install -m 0755 "$project_root/scripts/kariz.sh" /usr/local/bin/kariz-manager
install -m 0755 "$project_root/scripts/alirezatunel-join" /usr/local/bin/alirezatunel-join
for unit in kariz@.service kariz-panel.service kariz-agent.service alirezatunel-backpack@.service; do
  install -m 0644 "$project_root/systemd/$unit" "/etc/systemd/system/$unit"
done
systemctl daemon-reload
if [[ $mode == panel ]]; then
  /usr/local/bin/kariz-panel init
  systemctl enable --now kariz-panel.service
  systemctl restart kariz-panel.service
  echo 'ALIREZATUNEL installed. Replace SERVER_IP in this command to get a login link:'
  echo 'sudo kariz-panel login-link --host SERVER_IP'
else
  echo 'ALIREZATUNEL agent and BackPack engine installed.'
  echo 'Add this server in the panel, then run the displayed sudo alirezatunel-join CODE command.'
fi
